// sw.js
self.addEventListener('install', (event) => {
 event.waitUntil(
 caches.open('jee-pulse-cache-v1').then((cache) => {
 return cache.addAll([
 '/',
 '/index.html',
 '/daily-log.html',
 '/progress.html',
 '/syllabus.html',
 '/settings.html',
 '/css/styles.css',
 '/js/app.js',
 '/js/home.js',
 '/js/daily-log.js',
 '/js/progress.js',
 '/js/syllabus.js',
 '/js/settings.js',
 '/js/chart.min.js'
 ]);
 })
 );
});

self.addEventListener('fetch', (event) => {
 event.respondWith(
 caches.match(event.request).then((response) => {
 return response || fetch(event.request);
 })
 );
});