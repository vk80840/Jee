// js/home.js
document.addEventListener('DOMContentLoaded', () => {
 const quotes = [
 "Stay focused, you’ve got this!",
 "Every question you solve brings you closer to your goal!",
 "Keep pushing, JEE is within your reach!",
 "Hard work beats talent when talent doesn’t work hard."
 ];

 // Display random quote
 document.getElementById('motivational-quote').textContent = quotes[Math.floor(Math.random() * quotes.length)];

 // Load data
 const data = getData();
 const todayLog = data.logs.find(log => log.date === new Date().toISOString().split('T')[0]) || { study: [] };

 // Update stats
 const totalQuestions = todayLog.study.reduce((sum, s) => sum + (s.questionsPracticed || 0), 0);
 document.getElementById('questions-today').textContent = `${totalQuestions}/100`;
 document.getElementById('questions-progress').style.width = `${(totalQuestions / 100) * 100}%`;

 const totalMinutes = todayLog.study.reduce((sum, s) => sum + (s.time || 0), 0);
 document.getElementById('study-hours').textContent = `${Math.floor(totalMinutes / 60)}h ${totalMinutes % 60}m`;

 document.getElementById('streak').textContent = `${data.progress.streak} days`;

 const todayAttendance = data.progress.attendance.find(a => a.date === new Date().toISOString().split('T')[0]);
 document.getElementById('school-status').value = todayAttendance?.status || 'present';

 // Update subject progress
 const subjects = ['maths', 'physics', 'inorganic-chem', 'organic-chem', 'physical-chem'];
 subjects.forEach(subject => {
 const subjectData = todayLog.study.find(s => s.subject === subject) || { questionsPracticed: 0, time: 0 };
 document.getElementById(`${subject}-questions`).textContent = `${subjectData.questionsPracticed}/50`;
 document.getElementById(`${subject}-time`).textContent = `${Math.floor(subjectData.time / 60)}h ${subjectData.time % 60}m`;
 });

 // Update notes preview
 document.getElementById('notes-preview').textContent = todayLog.notes || 'No notes yet...';

 // Handle school status change
 document.getElementById('school-status').addEventListener('change', (e) => {
 const data = getData();
 const today = new Date().toISOString().split('T')[0];
 const existing = data.progress.attendance.find(a => a.date === today);
 if (existing) {
 existing.status = e.target.value;
 } else {
 data.progress.attendance.push({ date: today, status: e.target.value });
 }
 saveData(data);
 });
});