// js/settings.js
document.addEventListener('DOMContentLoaded', () => {
  const data = getData();

  // Initialize reminder settings
  document.getElementById('reminders').checked = data.settings.reminders;
  document.getElementById('reminder-time').value = data.settings.reminderTime;

  // Export data as JSON
  window.exportData = function() {
    const dataStr = JSON.stringify(getData(), null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'jee-pulse-data.json';
    a.click();
    URL.revokeObjectURL(url);
    showNotification('Data exported successfully!');
  };

  // Reset all data
  window.resetData = function() {
    if (confirm('Are you sure you want to reset all data? This cannot be undeleted.')) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_DATA));
      showNotification('All data reset!');
      // Update UI to reflect reset
      document.getElementById('reminders').checked = DEFAULT_DATA.settings.reminders;
      document.getElementById('reminder-time').value = DEFAULT_DATA.settings.reminderTime;
    }
  };

  // Save reminder settings
  window.saveSettings = function() {
    const data = getData();
    data.settings.reminders = document.getElementById('reminders').checked;
    data.settings.reminderTime = document.getElementById('reminder-time').value;
    saveData(data);
    showNotification('Reminder settings saved!');
  };
});