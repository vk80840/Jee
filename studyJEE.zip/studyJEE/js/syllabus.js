// js/syllabus.js
document.addEventListener('DOMContentLoaded', () => {
  const data = getData();
  const subjects = ['maths', 'physics', 'inorganic-chem', 'organic-chem', 'physical-chem'];

  subjects.forEach(subject => {
    // Calculate subject stats
    const questions = data.logs.reduce((sum, log) => 
      sum + log.study.filter(s => s.subject === subject).reduce((s, st) => s + (st.questionsPracticed || 0), 0), 0);
    const lectures = data.logs.reduce((sum, log) => 
      sum + log.study.filter(s => s.subject === subject && s.lecture).length, 0);
    const goals = data.logs.reduce((sum, log) => 
      sum + log.goals.filter(g => g.subject === subject).length, 0);
    
    // Calculate completion percentage (assuming 1000 questions per subject for simplicity)
    const totalQuestionsPerSubject = 1000; // Adjust based on actual JEE syllabus
    const completion = Math.min((questions / totalQuestionsPerSubject) * 100, 100).toFixed(1);

    // Update subject summary
    document.getElementById(`${subject}-questions`).textContent = questions;
    document.getElementById(`${subject}-lectures`).textContent = lectures;
    document.getElementById(`${subject}-goals`).textContent = goals;
    document.getElementById(`${subject}-completion`).textContent = `${completion}%`;

    // Render chapters and topics
    const chaptersDiv = document.getElementById(`${subject}-chapters`);
    data.syllabus[subject].forEach(ch => {
      const chapterDiv = document.createElement('div');
      chapterDiv.className = 'card fade-in';
      chapterDiv.innerHTML = `
        <h3 class="chapter-title" onclick="toggleChapter(this)">${ch.chapter} ▼</h3>
        <div class="chapter-content" style="display: none;">
          ${ch.topics.map(t => {
            const topicQuestions = data.logs.reduce((sum, log) => 
              sum + log.study.filter(s => s.subject === subject && s.topics.includes(t)).reduce((s, st) => s + (st.questionsPracticed || 0), 0), 0);
            const topicLectures = data.logs.reduce((sum, log) => 
              sum + log.study.filter(s => s.subject === subject && s.topics.includes(t) && s.lecture).length, 0);
            const topicGoals = data.logs.reduce((sum, log) => 
              sum + log.goals.filter(g => g.subject === subject && g.topic === t).length, 0);
            const topicCompletion = Math.min((topicQuestions / 100) * 100, 100); // Assume 100 questions per topic
            return `
              <div class="card fade-in topic-card">
                <p><span class="emoji">📌</span> ${t}</p>
                <p>Questions: ${topicQuestions}</p>
                <p>Lectures: ${topicLectures}</p>
                <p>Goals: ${topicGoals}</p>
                <div class="progress-bar"><div style="width: ${topicCompletion}%"></div></div>
              </div>
            `;
          }).join('')}
        </div>
      `;
      chaptersDiv.appendChild(chapterDiv);
    });
  });

  // Toggle chapter visibility
  window.toggleChapter = function(element) {
    const content = element.nextElementSibling;
    const isVisible = content.style.display === 'block';
    content.style.display = isVisible ? 'none' : 'block';
    element.innerHTML = element.innerHTML.replace(isVisible ? '▼' : '▲', isVisible ? '▲' : '▼');
    if (!isVisible) {
      content.querySelectorAll('.topic-card').forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.classList.add('fade-in');
      });
    }
  };
});