// js/progress.js
document.addEventListener('DOMContentLoaded', () => {
 const data = getData();

 // Update stats
 document.getElementById('days-completed').textContent = data.logs.length;
 document.getElementById('total-questions').textContent = data.progress.questions;
 document.getElementById('total-study-time').textContent = `${Math.floor(data.progress.studyHours / 60)}h ${data.progress.studyHours % 60}m`;
 const avgSleep = data.progress.sleep.reduce((sum, s) => sum + s.hours, 0) / (data.progress.sleep.length || 1);
 document.getElementById('avg-sleep').textContent = `${Math.round(avgSleep)}h`;

 // 30-day averages
 const last30Days = data.logs.slice(-30);
 const avgStudyHours = last30Days.reduce((sum, log) => sum + log.study.reduce((s, st) => s + (st.time || 0), 0), 0) / (last30Days.length || 1) / 60;
 document.getElementById('avg-study-hours').textContent = `${Math.round(avgStudyHours)}h`;
 const avgQuestions = last30Days.reduce((sum, log) => sum + log.study.reduce((s, st) => s + (st.questionsPracticed || 0), 0), 0) / (last30Days.length || 1);
 document.getElementById('avg-questions').textContent = Math.round(avgQuestions);

 // Subject-wise totals
 const subjects = ['maths', 'physics', 'inorganic-chem', 'organic-chem', 'physical-chem'];
 subjects.forEach(subject => {
 const total = data.logs.reduce((sum, log) => sum + log.study.filter(s => s.subject === subject).reduce((s, st) => s + (st.questionsPracticed || 0), 0), 0);
 document.getElementById(`${subject}-total`).textContent = `${total} questions`;
 });

 // Daily Routine Chart
 const todayLog = data.logs.find(log => log.date === new Date().toISOString().split('T')[0]) || { study: [] };
 const studyTime = todayLog.study.reduce((sum, s) => sum + (s.time || 0), 0);
 const sleepTime = data.progress.sleep.find(s => s.date === new Date().toISOString().split('T')[0])?.hours * 60 || 0;
 new Chart(document.getElementById('routine-chart'), {
 type: 'bar',
 data: {
 labels: ['Sleep', 'Study', 'Lectures', 'School', 'Breaks', 'Idle'],
 datasets: [{
 label: 'Today',
 data: [sleepTime, studyTime, 0, 0, 0, 1440 - (sleepTime + studyTime)],
 backgroundColor: ['#6bcb77', '#ff6b6b', '#4ecdc4', '#ffd93d', '#ff8c42', '#ddd']
 }]
 },
 options: { scales: { y: { beginAtZero: true, title: { display: true, text: 'Minutes' } } } }
 });

 // Attendance Calendar
 const calendar = document.getElementById('calendar');
 const today = new Date();
 const year = today.getFullYear();
 const month = today.getMonth();
 const daysInMonth = new Date(year, month + 1, 0).getDate();
 let html = '<table><tr><th>S</th><th>M</th><th>T</th><th>W</th><th>T</th><th>F</th><th>S</th></tr>';
 let day = 1;
 const firstDay = new Date(year, month, 1).getDay();
 for (let i = 0; i < 6; i++) {
 html += '<tr>';
 for (let j = 0; j < 7; j++) {
 if (i === 0 && j < firstDay || day > daysInMonth) {
 html += '<td></td>';
 } else {
 const date = `${year}-${(month + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
 const status = data.progress.attendance.find(a => a.date === date)?.status || (j === 0 ? 'holiday' : '');
 html += `<td class="${status}">${day}</td>`;
 day++;
 }
 }
 html += '</tr>';
 if (day > daysInMonth) break;
 }
 html += '</table>';
 calendar.innerHTML = html;

 document.getElementById('present-count').textContent = data.progress.attendance.filter(a => a.status === 'present').length;
 document.getElementById('absent-count').textContent = data.progress.attendance.filter(a => a.status === 'absent').length;
 document.getElementById('holiday-count').textContent = data.progress.attendance.filter(a => a.status === 'holiday').length;
});