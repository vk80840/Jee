// js/daily-log.js
let timerInterval;
let timerSeconds = 0;

document.addEventListener('DOMContentLoaded', () => {
 const data = getData();
 const todayLog = data.logs.find(log => log.date === new Date().toISOString().split('T')[0]) || { goals: [], study: [], notes: '' };

 // Populate dropdowns
 const subjects = ['maths', 'physics', 'inorganic-chem', 'organic-chem', 'physical-chem'];
 subjects.forEach(subject => {
 ['goal', 'study', 'lecture'].forEach(type => {
 const select = document.getElementById(`${type}-subject`);
 select.addEventListener('change', () => updateChapters(type, subject));
 });
 });

 // Update chapters and topics
 function updateChapters(type, selectedSubject) {
 const chapterSelect = document.getElementById(`${type}-chapter`);
 const topicSelect = document.getElementById(`${type}-topic`);
 chapterSelect.innerHTML = '<option value="">Select Chapter</option>';
 topicSelect.innerHTML = '<option value="">Select Topic</option>';
 if (selectedSubject) {
 const chapters = data.syllabus[selectedSubject] || [];
 chapters.forEach(ch => {
 chapterSelect.innerHTML += `<option value="${ch.chapter}">${ch.chapter}</option>`;
 });
 chapterSelect.addEventListener('change', () => {
 const selectedChapter = chapterSelect.value;
 topicSelect.innerHTML = '<option value="">Select Topic</option>';
 const chapter = chapters.find(c => c.chapter === selectedChapter);
 if (chapter) {
 chapter.topics.forEach(t => {
 topicSelect.innerHTML += `<option value="${t}">${t}</option>`;
 });
 }
 });
 }
 }

 // Display goals
 function renderGoals() {
 const goalList = document.getElementById('goal-list');
 goalList.innerHTML = '';
 todayLog.goals.forEach((goal, index) => {
 const div = document.createElement('div');
 div.className = `card ${goal.subject || ''} fade-in`;
 div.innerHTML = `
 <p>${goal.text || `${goal.subject}: ${goal.chapter} - ${goal.topic}`}</p>
 <input type="checkbox" ${goal.completed ? 'checked' : ''} onchange="toggleGoal(${index})">
 <button onclick="deleteGoal(${index})">Delete</button>
 `;
 goalList.appendChild(div);
 });
 }

 // Add text goal
 window.addTextGoal = function() {
 const text = document.getElementById('text-goal').value;
 if (text) {
 todayLog.goals.push({ text, completed: false });
 saveData(data);
 renderGoals();
 showNotification('Goal added!');
 document.getElementById('text-goal').value = '';
 }
 };

 // Add topic goal
 window.addTopicGoal = function() {
 const subject = document.getElementById('goal-subject').value;
 const chapter = document.getElementById('goal-chapter').value;
 const topic = document.getElementById('goal-topic').value;
 if (subject && chapter && topic) {
 todayLog.goals.push({ subject, chapter, topic, completed: false });
 saveData(data);
 renderGoals();
 showNotification('Topic goal added!');
 }
 };

 // Toggle goal completion
 window.toggleGoal = function(index) {
 todayLog.goals[index].completed = !todayLog.goals[index].completed;
 saveData(data);
 renderGoals();
 if (todayLog.goals[index].completed) {
 showNotification('Goal completed!');
 }
 };

 // Delete goal
 window.deleteGoal = function(index) {
 todayLog.goals.splice(index, 1);
 saveData(data);
 renderGoals();
 };

 // Save sleep
 window.saveSleep = function() {
 const bedTime = document.getElementById('bed-time').value;
 const wakeTime = document.getElementById('wake-time').value;
 if (bedTime && wakeTime) {
 const bed = new Date(`1970-01-01T${bedTime}:00`);
 let wake = new Date(`1970-01-01T${wakeTime}:00`);
 if (wake < bed) wake.setDate(wake.getDate() + 1);
 const hours = (wake - bed) / 1000 / 60 / 60;
 data.progress.sleep.push({ date: new Date().toISOString().split('T')[0], hours });
 saveData(data);
 showNotification('Sleep logged!');
 }
 };

 // Save study
 window.saveStudy = function() {
 const subject = document.getElementById('study-subject').value;
 const chapter = document.getElementById('study-chapter').value;
 const topics = Array.from(document.getElementById('study-topic').selectedOptions).map(o => o.value);
 const target = parseInt(document.getElementById('question-target').value) || 0;
 const practiced = parseInt(document.getElementById('questions-practiced').value) || 0;
 if (subject && chapter && topics.length) {
 todayLog.study.push({ subject, chapter, topics, questionsPracticed: practiced, target, time: 0 });
 data.progress.questions += practiced;
 saveData(data);
 showNotification('Study session logged!');
 }
 };

 // Save lecture
 window.saveLecture = function() {
 const subject = document.getElementById('lecture-subject').value;
 const chapter = document.getElementById('lecture-chapter').value;
 const topics = Array.from(document.getElementById('lecture-topic').selectedOptions).map(o => o.value);
 const duration = parseInt(document.getElementById('lecture-duration').value) || 0;
 if (subject && chapter && topics.length && duration) {
 todayLog.study.push({ subject, chapter, topics, time: duration, lecture: true });
 data.progress.studyHours += duration;
 saveData(data);
 showNotification('Lecture logged!');
 }
 };

 // Set lecture duration
 window.setLectureDuration = function(minutes) {
 document.getElementById('lecture-duration').value = minutes;
 };

 // Study timer
 window.startTimer = function() {
 document.getElementById('timer-start').disabled = true;
 document.getElementById('timer-stop').disabled = false;
 timerInterval = setInterval(() => {
 timerSeconds++;
 const h = Math.floor(timerSeconds / 3600);
 const m = Math.floor((timerSeconds % 3600) / 60);
 const s = timerSeconds % 60;
 document.getElementById('timer-display').textContent = `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
 }, 1000);
 };

 window.stopTimer = function() {
 clearInterval(timerInterval);
 document.getElementById('timer-start').disabled = false;
 document.getElementById('timer-stop').disabled = true;
 const minutes = Math.floor(timerSeconds / 60);
 if (minutes > 0) {
 const subject = document.getElementById('study-subject').value;
 if (subject) {
 todayLog.study.push({ subject, time: minutes });
 data.progress.studyHours += minutes;
 saveData(data);
 showNotification(`Logged ${minutes} minutes of study!`);
 }
 timerSeconds = 0;
 document.getElementById('timer-display').textContent = '00:00:00';
 }
 };

 // Save notes
 window.saveNotes = function() {
 todayLog.notes = document.getElementById('daily-notes').value;
 saveData(data);
 showNotification('Notes saved!');
 };

 // Initialize
 renderGoals();
 document.getElementById('daily-notes').value = todayLog.notes;
});