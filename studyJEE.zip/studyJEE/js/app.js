// js/app.js
const STORAGE_KEY = 'jee_pulse_data';
const DEFAULT_DATA = {
 theme: 'light',
 goals: [],
 logs: [],
 progress: {
 questions: 0,
 studyHours: 0,
 streak: 0,
 sleep: [],
 attendance: []
 },
 syllabus: {
 maths: [
 { chapter: 'Algebra', topics: ['Quadratic Equations', 'Matrices'] },
 { chapter: 'Calculus', topics: ['Limits', 'Derivatives'] }
 ],
 physics: [
 { chapter: 'Mechanics', topics: ['Kinematics', 'Dynamics'] }
 ],
 inorganicChem: [
 { chapter: 'Periodic Table', topics: ['Trends', 'Compounds'] }
 ],
 organicChem: [
 { chapter: 'Hydrocarbons', topics: ['Alkanes', 'Alkenes'] }
 ],
 physicalChem: [
 { chapter: 'Thermodynamics', topics: ['Laws', 'Equilibrium'] }
 ]
 },
 settings: {
 reminders: false,
 reminderTime: '08:00'
 }
};

// Initialize data
function initData() {
 if (!localStorage.getItem(STORAGE_KEY)) {
 localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_DATA));
 }
}

// Get data
function getData() {
 return JSON.parse(localStorage.getItem(STORAGE_KEY));
}

// Save data
function saveData(data) {
 localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

// Theme toggle
function toggleTheme() {
 const body = document.body;
 body.classList.toggle('dark');
 const data = getData();
 data.theme = body.classList.contains('dark') ? 'dark' : 'light';
 saveData(data);
}

// Reset daily logs
function resetDailyLogs() {
 const data = getData();
 const today = new Date().toISOString().split('T')[0];
 if (!data.logs.some(log => log.date === today)) {
 data.logs.push({ date: today, goals: [], study: [], notes: '' });
 saveData(data);
 }
}

// Simulated notification
function showNotification(message) {
 const modal = document.createElement('div');
 modal.className = 'modal active';
 modal.innerHTML = `
 <p>${message}</p>
 <button onclick="this.parentElement.remove()">Close</button>
 `;
 document.body.appendChild(modal);
 setTimeout(() => modal.remove(), 3000);
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
 initData();
 const data = getData();
 if (data.theme === 'dark') document.body.classList.add('dark');
 resetDailyLogs();
});